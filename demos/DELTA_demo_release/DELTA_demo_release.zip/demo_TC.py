import os
import random
import torch
import matplotlib.pyplot as plt
from utils import *

###############################
# Hyperparameters and Settings
###############################
# Dataset and experiment settings
DATA_NAME = 'balloons'  # dataset name (without suffix)
SAMPLE_RATE = '0.05'    # sampling rate string
MAT_DIR = 'data'        # directory for .mat files
FRAME_IDX = 0           # frame index to visualize (0-based)

# Training settings
EPOCH_NUM = 3100        # number of training epochs
MULTIHEADNUM = 2        # number of attention heads
ENCODER_NUM = 1         # number of encoder layers
LAMBDA = 1e-3           # lambda for loss
GAMMA = 10              # gamma for loss
EXPAND = 4              # expand factor for n4
OPTIMIZER_LR = 0.002    # learning rate
STEP_SIZE = 1500        # LR scheduler step size
SCHEDULER_GAMMA = 0.5   # LR scheduler gamma
CHECKPOINT_TEST = 100   # print interval

###############################
# Utility Functions
###############################


def prod(a, b):
    """Batch matrix multiplication for tensors."""
    a = a.permute(2, 0, 1)
    b = b.permute(2, 0, 1)
    d = torch.bmm(a, b)
    d = d.permute(1, 2, 0)
    return d

###############################
# Model Components
###############################


class EncoderLayer(nn.Module):
    def __init__(self, d_word, attn):
        super(EncoderLayer, self).__init__()
        self.d_word = d_word
        self.attn = attn

    def forward(self, x):
        query = x
        key = x
        value = x
        y = (x + self.attn(query, key, value)) / 2
        return y


class Encoder(nn.Module):
    def __init__(self, layer, layer_num):
        super(Encoder, self).__init__()
        self.layers = clones(layer, layer_num)

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x


def attention(query, key, value):
    tanh = torch.nn.Tanh()
    d_qkv = query.shape[-1]
    score = torch.matmul(query, key.transpose(-2, -1)) / np.sqrt(d_qkv)
    score = tanh(score)
    return torch.matmul(score, value), score


class MultiAttention(nn.Module):
    def __init__(self, d_word, headnum):
        super(MultiAttention, self).__init__()
        if d_word % headnum == 0:
            self.d_qkv = d_word // headnum
        else:
            print("the length of vector q,k,v can not be divided by the length of word vector ")
            exit(0)
        self.headnum = headnum
        self.Wq = nn.Linear(d_word, d_word, bias=False)
        self.Wk = nn.Linear(d_word, d_word, bias=False)
        self.Wv = nn.Linear(d_word, d_word, bias=False)
        self.Wz = nn.Linear(d_word, d_word, bias=False)
        self.attn = None
        self.attn_score = 0

    def forward(self, query, key, value):
        sentences_num = query.shape[0]
        query = self.Wq(query).view(sentences_num, -1, self.headnum, self.d_qkv).transpose(1, 2)
        key = self.Wk(key).view(sentences_num, -1, self.headnum, self.d_qkv).transpose(1, 2)
        value = self.Wv(value).view(sentences_num, -1, self.headnum, self.d_qkv).transpose(1, 2)
        x, self.attn_score = attention(query, key, value)
        x = x.transpose(1, 2).contiguous().view(sentences_num, -1, self.headnum * self.d_qkv)
        return self.Wz(x).squeeze(1)


class ForwardTransform(nn.Module):
    def __init__(self, multihead_num, encoder_num, n3, n4):
        super(ForwardTransform, self).__init__()
        self.D2_out = torch.nn.Conv3d(in_channels=n3, out_channels=n4, kernel_size=(1, 5, 5),
                                      padding=(0, 2, 2), bias=False)
        self.attn2 = MultiAttention(n4, multihead_num)
        self.decoder = Encoder(EncoderLayer(n4, self.attn2), encoder_num)
        self.leaky_relu = torch.nn.LeakyReLU()
        self.n3 = n3
        self.n4 = n4

    def forward(self, x):
        x = x.permute(2, 0, 1).unsqueeze(1).unsqueeze(0)
        x = self.D2_out(x)
        x = self.leaky_relu(x.squeeze(0).squeeze(1).permute(1, 2, 0))
        [n1, n2, n3] = x.shape
        x = x.reshape(n1 * n2, n3)
        x = self.decoder(x)
        x = x.reshape(n1, n2, n3)
        return x


class BackwardTransform(nn.Module):

    def __init__(self, multihead_num, encoder_num, n3, n4):
        super(BackwardTransform, self).__init__()
        self.D2_out = torch.nn.Conv3d(in_channels=n4, out_channels=n3, kernel_size=(1, 5, 5),
                                      padding=(0, 2, 2), bias=False)
        self.attn2 = MultiAttention(n4, multihead_num)
        self.decoder = Encoder(EncoderLayer(n4, self.attn2), encoder_num)
        self.leaky_relu = torch.nn.LeakyReLU()
        self.n3 = n3
        self.n4 = n4

    def forward(self, x):
        [n1, n2, n3] = x.shape
        x = x.reshape(n1 * n2, n3)
        x = self.decoder(x)
        x = x.reshape(n1, n2, n3)
        x = x.permute(2, 0, 1).unsqueeze(1).unsqueeze(0)
        x = self.D2_out(x)
        x = self.leaky_relu(x.squeeze(0).squeeze(1).permute(1, 2, 0))
        return x


class DELTALoss(nn.Module):
    def __init__(self):
        super(DELTALoss, self).__init__()

    def forward(self, f_x, mid_x, g_x, express, current_step, lambda_, gamma_, data_ob, mask):
        nuc_loss = torch.norm(express[:, :, current_step % express.shape[2]], 'nuc')
        express_loss = torch.norm(f_x-mid_x, p='fro')
        reconstruction_loss = torch.norm(mask * g_x - mask * data_ob, p='fro')
        loss = lambda_ * nuc_loss + gamma_ * express_loss + reconstruction_loss
        return loss


class DELTAm(nn.Module):
    def __init__(self, n2, n3, n4, multihead_num, encoder_num, lr, step_size, scheduler_gamma):
        super(DELTAm, self).__init__()
        self.optimizer = None
        self.scheduler = None
        self.loss_function = None
        self.lr = lr
        self.current_loss = 0
        self.multihead_num = multihead_num
        self.encoder_num = encoder_num
        self.express = nn.Parameter(1e-3*torch.ones(n2, n2, n4))
        self.f = ForwardTransform(multihead_num, encoder_num, n3, n4)
        self.g = BackwardTransform(multihead_num, encoder_num, n3, n4)
        self.step_size = step_size
        self.scheduler_gamma = scheduler_gamma

    def init_weight(self):
        with torch.no_grad():
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight)
                elif isinstance(m, nn.Conv2d):
                    nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')

    def init_train(self):
        self.init_weight()

    def init_optimizer(self, params):
        self.optimizer = torch.optim.Adam(params, lr=self.lr)
        self.scheduler = torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=self.step_size,
                                             gamma=self.scheduler_gamma, last_epoch=-1)
        self.loss_function = DELTALoss()

    def forward(self, x):
        f_x = self.f(x)
        mid_x = prod(f_x, self.express)
        g_x = self.g(mid_x)
        return f_x, self.express, mid_x, g_x

    def feed_data(self, x_in, input_data, lambda_, gamma_, current_step):
        data_ob = input_data["label"]
        mask = input_data["mask"]
        self.optimizer.zero_grad()
        f_x, express, mid_x, g_x = self.forward(x_in)
        loss = self.loss_function.forward(f_x, mid_x, g_x, express, current_step, lambda_, gamma_, data_ob, mask)
        self.current_loss = loss.item()
        loss.backward()
        self.optimizer.step()
        self.scheduler.step()
        with torch.no_grad():
            output_v = g_x.clone().cpu()
        return output_v

###############################
# Main Training and Evaluation
###############################


if __name__ == '__main__':

    # Data path
    print(f"*******task: TC, data_name: {DATA_NAME} and sampling_rate: {SAMPLE_RATE} ***********")
    gt_path = os.path.join(MAT_DIR, f"{DATA_NAME}_gt.mat")
    mask_path = os.path.join(MAT_DIR, f"{DATA_NAME}_{SAMPLE_RATE}_mask.mat")
    input_path = os.path.join(MAT_DIR, f"{DATA_NAME}_{SAMPLE_RATE}_input.mat")

    # Load data
    mat_gt = scio.loadmat(gt_path)
    data_gt = np.double(mat_gt["Nhsi"])
    mat_mask = scio.loadmat(mask_path)
    mask = mat_mask["mask"]
    mask = mask.astype(bool)
    mat_input = scio.loadmat(input_path)
    x_in = np.double(mat_input["input"])
    data_ob = np.zeros(data_gt.shape)
    data_ob[mask] = data_gt[mask]

    # Model parameters
    n2 = data_gt.shape[1]
    n3 = data_gt.shape[2]
    n4 = EXPAND * n3

    # Prepare tensors
    x_in_tensor = torch.tensor(x_in.copy(), dtype=torch.float32).cuda()
    mask_tensor = torch.tensor(mask.copy(), dtype=torch.int).cuda()
    data_ob_tensor = torch.tensor(data_ob.copy(), dtype=torch.float32).cuda()
    input_data = {"mask": mask_tensor, "label": data_ob_tensor}

    # Build model
    model = DELTAm(n2, n3, n4, MULTIHEADNUM, ENCODER_NUM, OPTIMIZER_LR, STEP_SIZE, SCHEDULER_GAMMA)
    params = [x for x in model.parameters()]
    x_in_tensor.requires_grad = True
    params += [x_in_tensor]
    model.init_train()
    model = model.cuda()
    model.init_optimizer(params)

    # Training loop
    print('Start training...')
    for i_iter in range(EPOCH_NUM):
        current_step = i_iter + 1
        recovery_tensor = model.feed_data(x_in_tensor, input_data, LAMBDA, GAMMA, current_step)
        if current_step % CHECKPOINT_TEST == 0:
            print(f"Epoch {current_step}/{EPOCH_NUM} finished.")
    print('Training finished.')

    # Convert result to numpy
    x_out = recovery_tensor.numpy()
    psnr, ssim, sam = qualify(x_out, data_gt)
    print('psnr:{},ssim:{},sam:{}'.format(psnr, ssim, sam))

    # Visualization (show one gray frame)
    plt.figure(figsize=(12, 4))
    plt.subplot(1, 3, 1)
    plt.title('Observed')
    plt.imshow(data_ob[:, :, FRAME_IDX], cmap='gray')
    plt.axis('off')
    plt.subplot(1, 3, 2)
    plt.title('Recovered')
    plt.imshow(x_out[:, :, FRAME_IDX], cmap='gray')
    plt.axis('off')
    plt.subplot(1, 3, 3)
    plt.title('Ground Truth')
    plt.imshow(data_gt[:, :, FRAME_IDX], cmap='gray')
    plt.axis('off')
    plt.tight_layout()
    plt.show()
