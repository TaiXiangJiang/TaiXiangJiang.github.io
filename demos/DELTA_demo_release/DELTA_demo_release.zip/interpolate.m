function Out=interpolate(I, Mask)
[n1, n2, n3]=size(Mask);
Out = zeros(n1, n2, n3);
[xGrid, yGrid] = meshgrid(1:n2, 1:n1);
for i=1:n3
    mask = Mask(:, :, i);
    temp = I(:, :, i);
    [Y, X] = find(mask == 1);
    V = temp(mask == 1);
    if length(X) >= 3
        try
            F = scatteredInterpolant(X, Y, V, 'natural', 'nearest');
            Out(:, :, i) = F(xGrid, yGrid);
        catch
            Out(:, :, i) = temp;
        end
    else
        Out(:, :, i) = temp;
    end
end
Out(isnan(Out)) = 128;
end
