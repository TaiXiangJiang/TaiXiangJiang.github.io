import scipy.io as scio
import copy
import torch.nn as nn
import numpy as np
from skimage.metrics import structural_similarity


def load_mat(path):
    """Load .mat file and return keys and data dict."""
    data = scio.loadmat(path)
    return data.keys(), data


def clones(module, num):
    """Produce N identical layers."""
    return nn.ModuleList([copy.deepcopy(module) for _ in range(num)])


def SAM(t, h, epsilon=1e-8):
    sigma_tr = np.dot(t, h)
    sigma_t2 = np.dot(t, t)
    sigma_r2 = np.dot(h, h)
    denominator = np.sqrt(sigma_t2 * sigma_r2) + epsilon
    cos_theta = np.clip(sigma_tr / denominator, -1.0, 1.0)
    angle = np.degrees(np.arccos(cos_theta))
    return angle


def MSAM(O, Ref):
    H, W, B = O.shape
    SAMV = np.zeros((H, W))

    for i in range(H):
        for j in range(W):
            a1 = O[i, j, :]
            a2 = Ref[i, j, :]
            SAMV[i, j] = SAM(a1, a2)
    valid_mask = ~np.isnan(SAMV)
    MSAM_value = np.mean(SAMV[valid_mask])
    return MSAM_value


def caculate_psnr(t, gt, data_range=255):
    mse = np.mean((t-gt) ** 2)
    return 10*np.log10(data_range ** 2 / mse)


def qualify(t, gt, final=True):
    n3 = t.shape[2]
    t_m = t * 255
    gt_m = gt * 255
    psnrs = []
    for i in range(n3):
        psnrs.append(caculate_psnr(gt_m[:,:,i], t_m[:,:,i], data_range=255))
    ssim = structural_similarity(gt_m, t_m, multichannel=True, gaussian_weights=True, sigma=1.5,
                                 use_sample_covariance=False, data_range=255)
    sam = MSAM(t_m, gt_m)
    if final:
        return np.mean(psnrs), ssim, sam
