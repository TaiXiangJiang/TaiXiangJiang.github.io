# TPAMI Tensor Completion Demos

This repository provides PyTorch implementations for several tensor completion and spectral imaging algorithms, including:

- **Robust Tensor Completion**
- **Snapshot Spectral Imaging**
- **Tensor Completion (MSI Tube)**

---

## Table of Contents
- [Introduction](#introduction)
- [Requirements](#requirements)
- [Getting Started](#getting-started)
- [Data Preparation](#data-preparation)
- [Usage](#usage)
- [Results](#results)
- [Citation](#citation)

---

## Introduction

Tensor completion and spectral imaging are important tasks in computer vision and machine learning. This repository provides clean, well-documented demo codes for:

- **Tensor Completion (MSI Tube)**: General tensor completion for multi-spectral images.

All demos are self-contained, with parameters and settings at the top of each script for easy modification.

---

## Requirements

- Python >= 3.7
- PyTorch >= 1.8
- numpy
- scipy
- matplotlib
- scikit-image

You can install all dependencies via:

```bash
pip install -r requirements.txt
```

---

## Getting Started

**Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

---

## Data Preparation

- Linear interpolation code can be found in `interpolation.m` and `interpolate.m`.

> **Note:**
> - The `utils.py` file must be placed in the same directory as the demo scripts or be accessible via your `PYTHONPATH`.

---

## Usage

Each demo is a single Python script. You can run them directly after setting parameters at the top of the file.


You can modify the dataset name, sampling rate, number of epochs, and other hyperparameters at the top of each script to switch experiments.

---

## Results

- After training, each demo will print metrics for the recovered result.
- The script will also display the observed, recovered, and ground truth images for a selected frame (as set by `FRAME_IDX`).

---

## License

This project is released under the MIT License. 