import h5py
import nibabel
import torch
import numpy as np
from scipy.io import savemat,loadmat

f = h5py.File(path)
f_kspace = f['kspace']'
data = nib.load(load_path)
label = data.dataobj[...]
label,_,_ = normalize_zero_to_one(label, eps=1e-6)