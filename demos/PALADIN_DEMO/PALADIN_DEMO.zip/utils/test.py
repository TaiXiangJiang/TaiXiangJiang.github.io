import random
import numpy as np
def normalize_zero_to_one(data, eps=0.):
    data_min = float(data.min())
    data_max = float(data.max())
    return (data - data_min) / (data_max - data_min + eps),data_max,data_min
def normalize_zero_to_one_reverse(data,data_max,data_min, eps=0.):
    return data*(data_max-data_min+eps)+data_min
a = np.random.rand(3,3)
b,max,min = normalize_zero_to_one(a,1e-6)
c = normalize_zero_to_one_reverse(b,max,min,1e-6)
print(a)
print(b)
print(c)
print(1)