import json
import random
import numpy as np
import nibabel as nib
from scipy import interpolate
import os
import csv
import pandas as pd
import matplotlib.pyplot as plt
import random
import time
import torch
import h5py
from scipy.io import savemat,loadmat
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
def prox_tnn(Y, rho):
    Y = Y.cpu().numpy()
    times = 1
    (n1, n2, n3) = Y.shape
    max12 = max(n1, n2)
    X = np.zeros((n1, n2, n3),dtype = complex)
    Y = np.fft.fft(Y, axis=2)
    tnn = 0
    trank = 0

    U, S, V = np.linalg.svd(Y[:,:,0])
    S =  np.maximum(S-rho*times, 0)
    tol = max12 * np.spacing(S.max())
    r = sum(S > tol)
    # r = np.sum(S > 0)
    S = np.diag(S)
    S = S[:r,:r]
    X[:,:,0] = np.dot(np.dot(U[:,0:r],S),V[0:r,:])
    # tnn = tnn + sum(sum(S))
    # trank = max(trank, r)
    if n3 % 2 == 0:
        halfn3 = n3//2
    elif n3 % 2 == 1:
        halfn3 = n3//2+1
    for i in range(1, halfn3):
        U, S, V = np.linalg.svd(Y[:,:,i])
        # print(i,n3-i)
        S = np.maximum(S-rho*times, 0)
        tol = max12 * np.spacing(S.max())
        r = sum(S > tol)
        # r = np.sum(S > 0)
        S = np.diag(S)
        S = S[:r,:r]
        # print(i)
        X[:,:,i] = np.dot(np.dot(U[:,0:r],S),V[0:r,:])
        X[:,:,n3-i] = np.conj(X[:,:,i])


    if n3%2 == 0:
        # print(halfn3)
        U, S, V = np.linalg.svd(Y[:,:,halfn3])
        S =  np.maximum(S-rho*times, 0)
        tol = max12 * np.spacing(S.max())
        r = sum(S > tol)
        # r = np.sum(S > 0)
        S = np.diag(S)
        S = S[:r,:r]
        X[:,:,halfn3] = np.dot(np.dot(U[:,0:r],S),V[0:r,:])

    # tnn = tnn/n3;
    X = np.fft.ifft(X,axis=2)   #为什么要逆变换
    X = np.real(X)
    X = torch.as_tensor(X)
    X = X.float()
    X = X.cuda()
    return X

def tnn_prox(Y, rho,tnn_type = 'tnn'):

    (n1, n2, n3) = Y.shape
    max12 = max(n1, n2)
    if tnn_type == 'tnn':
        X = torch.zeros(n1, n2, n3, dtype=torch.complex64, device=Y.device)
        Y = torch.fft.fft(Y.clone())
        for i in range(n3):
            U, S, V_h = torch.linalg.svd(Y[:, :, i])
            S = torch.maximum(S - rho, torch.zeros_like(S))
            tol = max12 * torch.finfo(S.dtype).eps
            r = sum(S > tol)
            # S = torch.diag(S[:r])
            S = torch.diag(S)
            S = S[:r, :r]
            X[:, :, i] = U[:, 0:r] @ torch.complex(S,torch.zeros_like(S)) @ V_h[0:r, :]
        X = torch.real(torch.fft.ifft(X.clone()))
    # X = normalize_zero_to_one(X, eps=1e-6)
    return X

def dim_prod(T):
    return np.product([x for x in T.shape])
def compare_psnr_norm(image, target):

    _, mean_rss, std_rss = normalize(target)
    image_, _, _ = normalize(image)
    image_ = (image_*std_rss) + mean_rss
    image_ = np.clip(image_,0, 1)
    target = np.clip(target, 0, 1)
    return compare_psnr(image_, target,data_range=1.0), compare_ssim(image_, target,data_range=1.0), image_
def quality(tensor1, tensor2):  ##tensor2: data_gt
    tensor1 = np.array(tensor1.cpu())
    tensor2 = np.array(tensor2.cpu())
    tensor1 = np.clip(tensor1,0, 1)
    tensor2 = np.clip(tensor2, 0, 1)
    psnr,ssim,_ = compare_psnr_norm(tensor1,tensor2)
    return psnr,ssim

def fftshift(x, axes=None):
    """
    Similar to np.fft.fftshift but applies to PyTorch Tensors
    """
    assert torch.is_tensor(x) is True
    if axes is None:
        axes = tuple(range(x.ndim()))
        shift = [dim // 2 for dim in x.shape]
    elif isinstance(axes, int):
        shift = x.shape[axes] // 2
    else:
        shift = [x.shape[axis] // 2 for axis in axes]
    return torch.roll(x, shift, axes)


def ifftshift(x, axes=None):
    """
    Similar to np.fft.ifftshift but applies to PyTorch Tensors
    """
    assert torch.is_tensor(x) is True
    if axes is None:
        axes = tuple(range(x.ndim()))
        shift = [-(dim // 2) for dim in x.shape]
    elif isinstance(axes, int):
        shift = -(x.shape[axes] // 2)
    else:
        shift = [-(x.shape[axis] // 2) for axis in axes]
    return torch.roll(x, shift, axes)


def fft2(data):
    assert data.shape[-1] == 2
    data = torch.view_as_complex(data)
    data = torch.fft.fftn(data, dim=(-3, -2), norm='ortho')
    data = torch.view_as_real(data)
    data = fftshift(data, axes=(-4, -3))
    return data

def ifft2(data):
    assert data.shape[-1] == 2
    data = ifftshift(data, axes=(-4, -3))
    data = torch.view_as_complex(data)
    data = torch.fft.ifftn(data, dim=(-3, -2), norm='ortho')
    data = torch.view_as_real(data)
    return data
def normalize(img):
    mean = img.mean()
    std = img.std()
    return (img - mean) / (std + 1e-11), mean, std
def normalize_zero_to_one(data, eps=0.):
    data_min = float(data.min())
    data_max = float(data.max())
    return (data - data_min) / (data_max - data_min + eps),data_max,data_min
def normalize_zero_to_one_reverse(data,data_max,data_min, eps=0.):
    return data*(data_max-data_min+eps)+data_min

def maxmin_normal3D(tensor):
    [n1,n2,n3] = tensor.shape
    tensor_new = tensor.copy()
    max_i = np.zeros([n3,1])
    min_i = np.zeros([n3,1])
    for i in range(n3):
        max_i[i] = np.max(tensor[:,:,i])
        min_i[i] = np.min(tensor[:,:,i])

        tensor_new[:,:,i] = (tensor[:,:,i]-min_i[i])/(max_i[i]-min_i[i])
    return tensor_new

def maxmin_normal4D(tensor):
    [n1,n2,n3,n4] = tensor.shape
    tensor_new = tensor.clone()
    max_i = torch.zeros([n4,1])
    min_i = torch.zeros([n4,1])
    for i in range(n4):
        max_i[i] = torch.max(tensor[:,:,:,i])
        min_i[i] = torch.min(tensor[:,:,:,i])

        tensor_new[:,:,:,i] = (tensor[:,:,:,i]-min_i[i])/(max_i[i]-min_i[i])
    return tensor_new


def img_to_ksp(data):
    data = data.unsqueeze(-1)
    assert data.shape[-1] == 1
    data = torch.cat([data, torch.zeros_like(data)], dim=-1)
    data = fft2(data)
    f = data
    return f

def img_to_underksp(data, mask):
    data = data.unsqueeze(-1)
    assert data.shape[-1] == 1
    data = torch.cat([data, torch.zeros_like(data)], dim=-1)
    data = fft2(data)
    mask = mask.unsqueeze(2)
    data = data * mask
    b = data
    return b

def sample_in_kspace(data, mask):   #fullsampled image to undersampled iamge
    data = data.unsqueeze(-1)
    assert data.shape[-1] == 1
    mask = torch.as_tensor(mask)   #转tensor处理傅里叶变换
    data = torch.cat([data, torch.zeros_like(data)], dim=-1)
    data = fft2(data)
    f = data
    mask = mask.unsqueeze(2)
    data = data * mask
    b = data
    data = ifft2(data)
    data = data[..., 0]
    return data,b,f
def ksp_to_img(kspdata):                #256X256X130X2
    assert kspdata.shape[-1] == 2
    kspdata = ifft2(kspdata)            #256X256X130X2
    kspdata = kspdata[..., 0]           #256X256X130
    imgdata = kspdata
    return imgdata
def ksp_to_img1(kspdata):                #256X256X130X2
    assert kspdata.shape[-1] == 2
    kspdata = ifft2(kspdata)            #256X256X130X2
    kspdata = kspdata         #256X256X130
    imgdata = kspdata
    return imgdata         # 256 256 32 2
def img_to_ksp1(data):
    data = fft2(data)
    f = data
    return f

def add_gaus_noise(input_tensor,sigma):
    tensor_degrd = input_tensor.clone()
    [n1, n2, n3] = input_tensor.shape
    noise_tensor = np.float32(np.random.normal(0, sigma / 255.,[n1,n2,n3]))
    # for i_slice in range(n3):
    #     noise_tensor[:,:,i_slice]= np.float32(np.random.normal(0, sigma / 255.,[n1,n2]))

    tensor_degrd+=noise_tensor
    #tensor_degrd += np.float32(np.random.normal(0, sigma / 255., input_tensor.shape)
    return tensor_degrd,noise_tensor

def mask_process(mask_path):
    data1 = loadmat(mask_path)
    mask1 = data1['mask']
    mask2 = mask1
    mask2 = np.stack((mask2, mask2), axis=-1)
    mask2 = torch.from_numpy(mask2)
    # mask2 = mask2.float()
    return mask2
def load_data(mask_s,usize,load_path):

    # f = h5py.File(path)
    # f_kspace = f['kspace']'
    # data = nib.load(load_path)
    # label = data.dataobj[...]
    # label,_,_ = normalize_zero_to_one(label, eps=1e-6)
    data = loadmat(load_path)          #data is supposed to be normalization
    label = data['data_gt']
    label1 = np.array(label)


    label = torch.from_numpy(label1)
    label = label[:,:,0:128]
    n3 = label.shape[2]
    for i in range(n3-usize):
        label[:,:,usize+i] = label[:,:,usize-i]
    # label = label.permute(1,2,0)
    data_gt = label
    data_gt = data_gt.float()
    savemat('testdata',{'data_gt': data_gt.numpy()})
    data_ob,b,_ = sample_in_kspace(data_gt,mask_s)   #input: full image , output: sampled image, sample kspace
    data_ob = torch.as_tensor(data_ob)
    # plt.imshow(data_gt[:, :, 0, 0], cmap='gray')
    # plt.show()
    # plt.imshow(data_ob[:, :, 0, 0], cmap='gray')
    # plt.show()

    return data_gt,  data_ob, b

def parse(opt_path, is_train=True):

    json_str = ''
    with open(opt_path, 'r') as f:
        for line in f:
            line = line.split('//')[0] + '\n'
            json_str += line

    opt = json.loads(json_str)#OrderedDict是干什么的

    opt['is_train'] = is_train
    opt['opt_path'] = opt_path
    return opt

def dim_prod(T):
    return np.product([x for x in T.shape])

def relative_error(x,x_pre):
    x_pre = x_pre.cpu().numpy()
    x = x.cpu().numpy()
    xk_norm = np.linalg.norm(x_pre)
    if xk_norm == 0:
        return np.linalg.norm(x-x_pre)
    else:
        return np.linalg.norm(x-x_pre)/ xk_norm


def random_permute(tensor,rand):

    if(rand==1):
        tensor = tensor.permute(1,2,0)
    if(rand==2):
        tensor = tensor.permute(0,1,2)
    if(rand==3):
        tensor = tensor.permute(0,2,1)
    return tensor

def random_permute_reverse(tensor,rand):
    if(rand==1):
        tensor = tensor.permute(2,0,1)
    if(rand==2):
        tensor = tensor.permute(0,1,2)
    if(rand==3):
        tensor = tensor.permute(0,2,1)
    return tensor

def plot_data(iter,quality1,quality2,quality3,quality4,quality_name,labda):
    plt.figure(figsize=(10, 10))
    xaxis = range(0,iter)
    yaxis1 = quality1
    yaxis2 = quality2
    yaxis3 = quality3
    yaxis4 = quality4
    plt.plot(xaxis, yaxis1, c='red',label='X')
    plt.plot(xaxis, yaxis2, c='blue',label='Y')
    plt.plot(xaxis, yaxis3, c='green',label='Z')
    plt.plot(xaxis, yaxis4, c='yellow',label='W')
    plt.legend()
    plt.scatter(xaxis, yaxis1, c='red',label='X')
    plt.scatter(xaxis, yaxis2, c='blue',label='Y')
    plt.scatter(xaxis, yaxis3, c='green',label='Z')
    plt.scatter(xaxis, yaxis4, c='yellow',label='W')
    if quality_name == 'PSNR':
        y_ticks = range(36,42)
    if quality_name == 'SSIM':
        y_ticks = range(0,1)
    plt.yticks(y_ticks[::1])
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.xlabel("iter", fontdict={'size': 16})
    plt.ylabel(quality_name, fontdict={'size': 16})
    plt.title("quality_change("+"labda="+str(labda)+"_"+"rho="+str(10)+")", fontdict={'size': 20})
    plt.savefig("figure_data/"+str(labda)+quality_name+".png")
    plt.show()


