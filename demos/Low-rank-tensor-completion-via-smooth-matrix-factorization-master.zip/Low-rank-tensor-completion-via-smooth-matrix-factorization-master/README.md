******************************************************************************
        Low-rank tensor completion via smooth matrix factorization
******************************************************************************

         Copyright: Yu-Bang Zheng, Ting-Zhu Huang, Teng-Yu Ji, 
                   Xi-Le Zhao, Tai-Xiang Jiang, and Tian-Hui Ma

 1). Get Started

 Run the following Demo_LRTC to run SMF-LRTC.

 2). Details

 More detail can be found in [1]

    [1] Y.-B. Zheng, T.-Z. Huang*, T.-Y. Ji, X.-L. Zhao*, T.-X. Jiang, and T.-H. Ma,
        Low-rank tensor completion via smooth matrix factorization.

 3). Please cite our paper if you use any part of our source code or data.
