# DAP+: Degradation Accordant Plug-and-Play for Low-Rank Tensor Recovery

[![Paper](https://img.shields.io/badge/Paper-Pattern%20Recognition-blue)](https://doi.org/10.1016/j.patcog.2025.112612)

This repository contains the official implementation of the paper: **"Degradation accordant plug-and-play for low-rank tensor recovery"**, published in *Pattern Recognition*, 2026.


## 🛠️ Requirements

The code was tested on a Windows 10 environment with an RTX 2080Ti GPU and AMD Ryzen 9 3950X CPU.


### Dependencies

* Python 3.7
* torch 1.9.0
* torch-dct 0.1.5
* numpy 1.21.2
* scikit-image 0.18.3
* scikit-learn 1.0.2
* MATLAB (for calculating quantitative metrics)

## 📂 Datasets

1.  **Multi-Spectral Images (MSI):** [CAVE Dataset](https://cave.cs.columbia.edu/repository/Multispectral) 
2.  **Color/Gray Videos:** [Yuv Dataset](http://trace.eas.asu.edu/yuv/) 
3.  **Color Images:** [Urban100 Dataset](https://github.com/jbhuang0604/SelfExSR) ([Kaggle Mirror](https://www.kaggle.com/datasets/harshraone/urban100)) 


## 🧩 Plug-in Networks

**Denoiser**
* DRUNet [Code](https://github.com/cszn/DPIR) \[1\]

**Inpainter**
* CRUnet: An inpainter pretrained by us on color images for image completion tasks with random missing pixels). [Baidu Drive](https://pan.baidu.com/s/1X3_E33q4vCz1E-jrnfh_IA) (Extraction Code: ``` kkll```)
* LBAM [Code](https://github.com/Vious/LBAM_Pytorch/tree/master) \[2\]

Please download and put the source code of these plug-in networks in corresponding folders as

```text
Project_Root/
├── Inpainter/
│   ├── CRUnet/
│   │   ├── checkpoints
│   │   ├── ...
│   │   └── main_train_gray_completion.py
│   └── LBAM/
│       ├── models
│       ├── ...
│       └── inpainting.py
├── Denoiser/
│   └── DRUNet/
│       ├── models
│       ├── ...
│       └── main_dpir_denoising.py
├── Demo_MSI.py
├── Demo_Video.py
└── Readme.md
```

## 🚀 Experiments & Reproduction

This package provides demos for the four experiments detailed in Section 6 of the paper.
1.  **Multi-Spectral Image (MSI) Recovery**: Demo_MSI.py
2.  **Color Video Recovery**: Demo_Video_color.py
3.  **Gray Video Recovery**: Demo_Video.py
4.  **Color Image Recovery**: Demo_RGB_struct_missing.py

## **Citation**
If you find this code or work helpful, please cite our paper:

```
@article{DAPPLUS,
title = {Degradation accordant plug-and-play for low-rank tensor recovery},
journal = {Pattern Recognition},
volume = {172},
pages = {112612},
year = {2026},
issn = {0031-3203},
doi = {https://doi.org/10.1016/j.patcog.2025.112612},
author = {Yexun Hu and Zixin Tang and Tai-Xiang Jiang and Xi-Le Zhao and Guisong Liu},
}

@inproceedings{hu2022degradation,
  title={Degradation Accordant Plug-and-Play for Low-Rank Tensor Completion},
  author={Hu, Yexun and Jiang, Tai-Xiang and Zhao, Xi-Le},
  booktitle={Proceedings of the  Thirty-First International Joint Conference on Artificial Intelligence},
  pages={1843--1849},
  year={2022}
}
```


## **Acknowledgement**

We gratefully acknowledge the creators of the public datasets used in this research. The availability of these data was instrumental in the development and validation of our methods.

## **References**
\[1\] Zhang, K., Li, Y., Zuo, W., Zhang, L., Van Gool, L., & Timofte, R. (2021). Plug-and-play image restoration with deep denoiser prior. IEEE Transactions on Pattern Analysis and Machine Intelligence, 44(10), 6360-6376.

\[2\] Xie, C., Liu, S., Li, C., Cheng, M. M., Zuo, W., Liu, X., ... & Ding, E. (2019). Image inpainting with learnable bidirectional attention maps. In Proceedings of the IEEE/CVF International Conference on Computer Vision (pp. 8858-8867).