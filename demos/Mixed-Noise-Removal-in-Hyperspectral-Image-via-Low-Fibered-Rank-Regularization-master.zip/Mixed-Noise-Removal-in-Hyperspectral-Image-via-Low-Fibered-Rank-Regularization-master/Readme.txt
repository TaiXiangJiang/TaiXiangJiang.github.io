# code TGRS-low-fibered-rank
********************************************************************************
 Mixed Noise Removal in Hyperspectral Image via Low-Fibered-Rank Regularization
********************************************************************************

 Copyright:     Yu-Bang Zheng, Ting-Zhu Huang, Xi-Le Zhao, 
             Tai-Xiang Jiang, and Tian-Hui Ma, and Teng-Yu Ji
                   
********************************************************************************
********************************************************************************
  1). Get Started
  
  Run Demo.
  
  2). Details
  
  More detail can be found in [1]

  [1] Y.-B. Zheng, T.-Z. Huang, X.-L. Zhao, T.-X. Jiang, T.-H. Ma, and T.-Y. Ji.
      Mixed Noise Removal in Hyperspectral Image via Low-Fibered-Rank Regularization.
********************************************************************************

  3). Please cite our paper if you use any part of our source code.