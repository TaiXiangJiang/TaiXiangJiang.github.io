from config.dataset_config import getData
from eval_utils import test_autoattack, test_robust
from networks.resnet import ResNet18, ResNet34,ResNet50
from networks.wideresnet import WideResNet, Yao_WideResNet
from networks.mobilenetv2 import MobileNetV2
from networks.vgg import VGG
import torch.backends.cudnn as cudnn
import argparse
import torch
import torch.nn as nn
from AE import autoencoder,autoencoder2,UNet
import os
from networks.wideresnet import WideResNet, Yao_WideResNet
from collections import OrderedDict
os.environ["CUDA_VISIBLE_DEVICES"] = '0'

parser = argparse.ArgumentParser(description='PyTorch Test')
parser.add_argument('--dataset', type=str, default='CIFAR10')
parser.add_argument('--model', type=str, default='resnet18')
parser.add_argument('--method', type=str, default='AE_AdaAD')
parser.add_argument('--bs', default=100, type=int)
parser.add_argument('--eps', default=8/255, type=float)
parser.add_argument('--steps', default=10, type=int)
parser.add_argument('--random-start', default=1, type=int)
parser.add_argument('--coeff', default=0.1, type=float)  # for jsma, cw, ela
args = parser.parse_args()


num_classes, train_data, test_data = getData(args.dataset)

trainloader = torch.utils.data.DataLoader(
    train_data,
    batch_size=args.bs,
    shuffle=True,
    num_workers=2,
    pin_memory=True)
testloader = torch.utils.data.DataLoader(
    test_data,
    batch_size=args.bs,
    shuffle=False,
    num_workers=4,
    pin_memory=True)
use_cuda = torch.cuda.is_available()
print('use_cuda:%s' % str(use_cuda))
device = 'cuda' if torch.cuda.is_available() else 'cpu'
if device == 'cuda':
    cudnn.benchmark = True

# Model
if args.model == 'mobilenetV2':
    basic_net = MobileNetV2(num_classes=num_classes)
elif args.model == 'resnet18':
    basic_net = ResNet18(num_classes)
elif args.model == 'wideresnet34_10':
    basic_net = WideResNet(num_classes=num_classes)
elif args.model == 'wideresnet34_20':
    basic_net = Yao_WideResNet(num_classes=num_classes, depth=34, widen_factor=20, sub_block1=False)
elif args.model == 'Chen2021WRN34_10':
    basic_net = Yao_WideResNet(num_classes=num_classes, depth=34, widen_factor=10, sub_block1=True)
else:
    raise NotImplementedError




model_path = ''  # The model path you want to evaluate
print('model path:', model_path)
reformer_path=''#The AE path
print('reformer path:', reformer_path)

basic_net.load_state_dict(torch.load(model_path)['net'])
basic_net.to(device)
basic_net.eval()

reformer_model = autoencoder2(3)#the AE you choose
reformer_model.load_state_dict(torch.load(reformer_path))
reformer_model.to(device)
reformer_model.eval()

print(args.model)

print('Evaluate FGSM:')
test_robust(basic_net, reformer_model,attack_type='fgsm', c=args.eps, num_classes=num_classes,
            testloader=testloader, loss_fn=nn.CrossEntropyLoss(), req_count=10000)
print('Evaluate PGD:')
test_robust(basic_net, reformer_model,attack_type='pgd', c=args.eps, num_classes=num_classes,
            testloader=testloader, loss_fn=nn.CrossEntropyLoss(), req_count=10000)
print('Evaluate CW:')
test_robust(basic_net,reformer_model, attack_type='cw', c=args.coeff, num_classes=num_classes,
            testloader=testloader, loss_fn=nn.CrossEntropyLoss(), req_count=10000)
print('Evaluate AA:')
test_autoattack(basic_net, reformer_model,testloader, num_classes=num_classes,norm='Linf', eps=args.eps,
                version='standard', verbose=False)

