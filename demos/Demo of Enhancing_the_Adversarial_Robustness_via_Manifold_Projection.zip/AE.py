import os
import sys
import torch
import torchvision
from torch import nn
from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
import torch.nn.functional as F
from torchsummary import summary
from torch.utils.data.sampler import SubsetRandomSampler
import numpy as np
import copy
import pickle

from optparse import OptionParser
from config.dataset_config import getData

class autoencoder(nn.Module):# the autoencoder for CIFAR-100
    def __init__(self, in_channel):
        super(autoencoder, self).__init__()
        self.conv1 = nn.Conv2d(in_channel, 3, 3, padding=1)
        self.conv2 = nn.Conv2d(3, 3, 3, padding=1)
        self.conv3 = nn.Conv2d(3, in_channel, 3, padding=1)
        self.sig = nn.Sigmoid()

    def forward(self, x):
        x = self.sig(self.conv1(x))
        x = self.sig(self.conv2(x))
        x = self.sig(self.conv3(x))
        return x


class autoencoder2(nn.Module):# the autoencoder for CIFAR-10
    def __init__(self, in_channel):
        super(autoencoder2, self).__init__()
        self.conv1 = nn.Conv2d(in_channel, 3, 3, padding=1)
        self.conv2 = nn.Conv2d(3, 3, 3, padding=1)
        self.conv3= nn.Conv2d(3, in_channel, 3, padding=1)
        self.sig = nn.Sigmoid()

    def forward(self, x):
        x = self.sig(self.conv1(x))
        x = self.sig(self.conv2(x))
        x = self.sig(self.conv3(x))
        return x

class DoubleConv(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DoubleConv, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, 1, 1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, 1, 1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.conv(x)
class UNet(nn.Module):# the autoencoder for Tiny ImageNet
    def __init__(self, in_channels):#a simplified U-Net consisting of one downsampling and one upsampling block as the autoencoder.
        super(UNet, self).__init__()
        self.conv1 = DoubleConv(in_channels, 64)
        self.pool = nn.MaxPool2d(2)
        self.conv2 = DoubleConv(64, 128)#1layers
        # self.conv3 = DoubleConv(128, 256)#2layers
        # self.conv4 = DoubleConv(256, 512)#3layers
        # self.conv5 = DoubleConv(512, 1024)
        # self.upconv1 = nn.ConvTranspose2d(1024, 512, 2, 2)
        # self.conv6 = DoubleConv(1024, 512)
        # self.upconv2 = nn.ConvTranspose2d(512, 256, 2, 2)#3layers
        # self.conv7 = DoubleConv(512, 256)
        # self.upconv3 = nn.ConvTranspose2d(256, 128, 2, 2)#2layers
        # self.conv8 = DoubleConv(256, 128)
        self.upconv4 = nn.ConvTranspose2d(128, 64, 2, 2)#1layers
        self.conv9 = DoubleConv(128, 64)
        self.outconv = nn.Conv2d(64, in_channels, 1)

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(self.pool(x1))#1layers
        # x3 = self.conv3(self.pool(x2))#2layers
        # x4 = self.conv4(self.pool(x3))#3layers
        # x5 = self.conv5(self.pool(x4))
        # x = self.upconv1(x5)
        # x = torch.cat([x4, x], dim=1)
        # x = self.conv6(x)
        # x = self.upconv2(x)#3layers
        # x = torch.cat([x3, x], dim=1)
        # x = self.conv7(x)
        # x = self.upconv3(x3)#2layers
        # x = torch.cat([x2, x], dim=1)
        # x = self.conv8(x)
        x = self.upconv4(x2)#1layers
        x = torch.cat([x1, x], dim=1)
        x = self.conv9(x)
        x = self.outconv(x)
        return x

def get_args():
    parser = OptionParser()
    parser.add_option('--dataset', type=str, default='CIFAR10')
    parser.add_option('--bs', default=200, type='int', help='batch size')
    parser.add_option('--epochs', dest='epochs', default=100, type='int',
                      help='number of epochs')
    parser.add_option('--classes', dest='classes', default=10, type='int',
                      help='number of classes')
    parser.add_option('--channels', dest='channels', default=3, type='int',
                      help='number of channels')
    parser.add_option('--width', dest='width', default=32, type='int',
                      help='image width')
    parser.add_option('--height', dest='height', default=32, type='int',
                      help='image height')
    parser.add_option('--model_number', dest='model_number', default=2, type='int',
                      help='autoencoder number(1 or 2 or 3)')
    parser.add_option('--gpu', dest='gpu', type='string',
                      default='gpu', help='gpu or cpu')
    parser.add_option('--device1', dest='device1', default=0, type='int',
                      help='device1 index number')
    parser.add_option('--device2', dest='device2', default=-1, type='int',
                      help='device2 index number')
    parser.add_option('--device3', dest='device3', default=-1, type='int',
                      help='device3 index number')
    parser.add_option('--device4', dest='device4', default=-1, type='int',
                      help='device4 index number')

    (options, args) = parser.parse_args()
    return options


def train_net(model, args):
    num_epochs = args.epochs
    gpu = args.gpu
    # hyper parameter for training
    learning_rate = 1e-3
    v_noise = 0.1
    reg_strength = 1e-9

    # set device configuration
    device_ids = []

    if gpu == 'gpu':
        if not torch.cuda.is_available():
            print("No cuda available")
            raise SystemExit
        device = torch.device(args.device1)
        device_ids.append(args.device1)
        if args.device2 != -1:
            device_ids.append(args.device2)

        if args.device3 != -1:
            device_ids.append(args.device3)

        if args.device4 != -1:
            device_ids.append(args.device4)
    else:
        device = torch.device("cpu")

    if len(device_ids) > 1:
        model = nn.DataParallel(model, device_ids=device_ids)
    model = model.to(device)

    num_classes, train_data, test_data = getData(args.dataset)

    train_loader = torch.utils.data.DataLoader(
        train_data,
        batch_size=args.bs,
        shuffle=True,
        num_workers=4,
        pin_memory=True)
    val_loader = torch.utils.data.DataLoader(
        test_data,
        batch_size=200,
        shuffle=False,
        num_workers=4,
        pin_memory=True)
    model_folder = os.path.abspath('./checkpoints')
    if not os.path.exists(model_folder):
        os.mkdir(model_folder)

    if args.model_number == 1:# the model path of AE for CIFAR-100
        model_path = os.path.join(model_folder, 'autoencoder1_3layers.pth')
    elif args.model_number == 2:# the model path of AE for CIFAR-10
        model_path = os.path.join(model_folder, 'autoencoder2_3layers.pth')
    elif args.model_number == 3:# the model path of AE for Tiny ImageNet
        model_path = os.path.join(model_folder, 'Unet_1layers.pth')

    # loss function and optimizer
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters())

    display_steps = 10
    global best_loss
    best_loss = 1e10
    for epoch in range(num_epochs):  # loop over the dataset multiple times

        model.train()
        epoch_size = 0
        running_loss = 0

        lambda2 = torch.tensor(reg_strength)
        l2_reg = torch.tensor(0.)

        for batch_idx, (data, _) in enumerate(train_loader):

            noise = v_noise * np.random.normal(size=np.shape(data))
            noise = torch.from_numpy(noise)

            noisy_train_data = data.double() + noise

            noisy_train_data.clamp(0.0, 1.0)

            noisy_train_data = noisy_train_data.to(device).float()

            data = data.to(device).float()

            optimizer.zero_grad()

            output = model(noisy_train_data)

            loss = criterion(output, data)

            for param in model.parameters():
                l2_reg=l2_reg.to(device)
                l2_reg += torch.norm(param)

            loss += lambda2 * l2_reg.detach().cpu()

            loss.backward()
            optimizer.step()

            if batch_idx % display_steps == 0:
                print('    ', end='')
                print('batch {:>3}/{:>3}, loss {:.4f}\r' \
                      .format(batch_idx + 1, len(train_loader), loss.item()))

        # evalute
        print('Finished epoch {}, starting evaluation'.format(epoch + 1))

        model.eval()
        lambda2 = torch.tensor(reg_strength)
        l2_reg = torch.tensor(0.)
        with torch.no_grad():
            for data, _ in val_loader:
                data = data.to(device).float()
                target = data.to(device).float()
                output = model(data)
                loss = criterion(output, target)
                for param in model.parameters():
                    l2_reg = l2_reg.to(device)
                    l2_reg += torch.norm(param)
                loss += lambda2 * l2_reg.detach().cpu()
                running_loss += loss.item()
        validate_loss = running_loss / len(val_loader)

        if validate_loss < best_loss:
            print('best validation loss : {:.4f}'.format(validate_loss))

            best_loss = validate_loss

            print("saving best model")

            model_copy = copy.deepcopy(model)
            model_copy = model_copy.cpu()
            model_state_dict = model_copy.state_dict()
            torch.save(model_state_dict, model_path)


if __name__ == "__main__":
    args = get_args()
    n_channels = args.channels
    model = None
    if args.model_number == 1:#AE for CIFAR-100
        model = autoencoder(n_channels)
    elif args.model_number == 2:#AE for CIFAR-10
        model = autoencoder2(n_channels)
    elif args.model_number == 3:#AE for Tiny ImageNet
        model = UNet(n_channels)
    else:
        print("wrong model number : must be 1 or 2 or 3")
        raise SystemExit

    print('Training Autoencoder {}'.format(str(args.model_number)))
    summary(model, input_size=(n_channels, args.height, args.width), device='cpu')
    train_net(model, args)
    print('best validation loss : {:.4f}'.format(best_loss))
