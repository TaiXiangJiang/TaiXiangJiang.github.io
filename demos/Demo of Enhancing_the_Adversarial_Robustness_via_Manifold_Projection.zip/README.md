# Enhancing the Adversarial Robustness via Manifold Projection

Code for the paper Enhancing the Adversarial Robustness via Manifold Projection.

## Environment settings and libraries we used in our experiments

The code was evaluated using the following environment settings and libraries:
- OS: Linux
- GPU: NVIDIA GTX3090, A100
- Cuda: 11.2, Cudnn: 8.0
- Python: 3.8
- PyTorch: 1.10.0
- AutoAttack
- advertorch

## Acknowledgement

The Tiny ImageNet dataset can be downloaded by the link [Tiny ImageNet](http://cs231n.stanford.edu/tiny-imagenet-200.zip).

## Requirements
- Install or download [AutoAttack](https://github.com/fra31/auto-attack):
We recommend that you first download the ZIP file from https://github.com/fra31/auto-attack, then add it to your working directory and extract it before running the command:
```.bash
python setup.py install
```
Or you can simply run this command to download AutoAttack directly:
```.bash
pip install git+https://github.com/fra31/auto-attack
```
- Install or download [advertorch](https://github.com/BorealisAI/advertorch):
```.bash
pip install advertorch
```
## Training Commands

To begin with, we need to run [`AE.py`] to obtain the pre-trained autoencoder (AE).
For example, train an AE with the architecture detailed in Table 2 on the CIFAR-10 dataset, run the command:

```.bash
python AE.py \
    --dataset CIFAR10 \
    --bs 200 \
    --epochs 100 \
    --classes 10 \
    --channels 3 \
    --width 32 \
    --height 32 \
    --model_number 2 \
    --gpu gpu
```

Then we run [`AE_AT.py`] to train a WideResNet-34-20 model on the CIFAR-10 dataset via the proposed PGD-AT (AE) in the paper as the robust teacher model, run the command:

```.bash
python AE_AT.py \
    --dataset CIFAR10 \
    --model Chen2021LTD_WRD34_20 \
    --method AE_AT \
    --reformer autoencoder2 \
    --reformer_path checkpoints/autoencoder2_3layers.pth \
    --channels 3 \
    --epsilon 8 \
    --num_steps 10 \
    --step_size 2 \
    --epochs 110 \
    --bs 128 \
    --lr_max 0.1 \
    --lr_schedule piecewise \
    --gpu_id 0
```

We run [`AE_AdaAD.py`] to train a ResNet-18 model on the CIFAR-10 dataset via the proposed AdaAD (AE) in the paper by using the above-mentioned teacher model, run the command:

```.bash
python AE_AdaAD.py \
    --dataset CIFAR10 \
    --model resnet18 \
    --method AE_AdaAD \
    --teacher_model Chen2021LTD_WRD34_20 \
    --reformer autoencoder2 \
    --reformer_path checkpoints/autoencoder2_3layers.pth \
    --channels 3 \
    --epsilon 8 \
    --num_steps 10 \
    --step_size 2 \
    --epochs 200 \
    --bs 128 \
    --lr_max 0.1 \
    --lr_schedule piecewise \
    --gpu_id 0
```

## Evaluation Commands

We run [`main_eval.py`] to evaluate the above-mentioned ResNet-18 model on the CIFAR-10 dataset, run the command:

```.bash
python main_eval.py \
    --dataset CIFAR10 \
    --model resnet18 \
    --method AE_AdaAD \
    --bs 100 \
    --eps 8/255 \
    --steps 10 \
    --random-start 1 \
    --coeff 0.1 
```
